from pathlib import Path

import subprocess
import sys
import signal
import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

app = FastAPI(
    title="Powertown MVP",
    version="0.1.0",
    description="Minimal internal platform to capture and review multimodal building observations.",
)

templates = Jinja2Templates(directory="backend/app/templates")

uploads_dir = Path("data/uploads")
uploads_dir.mkdir(parents=True, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=str(uploads_dir)), name="uploads")

# IMPORTANT: serve artifact files at a *different* prefix than the /artifacts API
artifacts_dir = Path("data/artifacts")
artifacts_dir.mkdir(parents=True, exist_ok=True)
app.mount("/artifact-files", StaticFiles(directory=str(artifacts_dir)), name="artifact-files")

static_dir = Path("backend/app/static")
static_dir.mkdir(parents=True, exist_ok=True)
app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


@app.get("/favicon.ico", include_in_schema=False)
def favicon():
    return Response(status_code=204)


# --- Route wiring ---
from backend.app.routes import export
from backend.app.routes import artifacts, buildings, parks, ui
from backend.app.routes import search, artifact_actions, ui_artifacts

app.include_router(parks.router, prefix="/industrial-parks", tags=["industrial-parks"])
app.include_router(buildings.router, prefix="/buildings", tags=["buildings"])
app.include_router(artifacts.router, prefix="/artifacts", tags=["artifacts"])
app.include_router(ui_artifacts.router, tags=["ui"])

# new
app.include_router(search.router, prefix="/search", tags=["search"])
app.include_router(artifact_actions.router, tags=["artifact-actions"])

app.include_router(ui.router, tags=["ui"])
app.include_router(export.router, prefix="/export", tags=["export"])


# create a worker to process the artifacts
_worker_process: subprocess.Popen | None = None


@app.on_event("startup")
def start_worker():
    global _worker_process

    # Avoid double-spawning when using --reload
    if os.environ.get("RUN_MAIN") != "true":
        return

    print("Starting background worker process...")

    _worker_process = subprocess.Popen(
        [sys.executable, "-m", "backend.scripts.worker"],
        stdout=sys.stdout,
        stderr=sys.stderr,
        env=os.environ.copy(),
    )


@app.on_event("shutdown")
def stop_worker():
    global _worker_process

    if _worker_process and _worker_process.poll() is None:
        print("Stopping background worker...")
        _worker_process.send_signal(signal.SIGTERM)
        try:
            _worker_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            _worker_process.kill()
